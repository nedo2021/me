
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
// Add missing import for Play icon
import { Play } from 'lucide-react';

const WINDOW_WIDTH = 900;
const WINDOW_HEIGHT = 600;

// Re-using the logo for consistency
const TEAM_LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFmklEQVR4nO2dW0hcVxjH/6MmdUisMTYmGjE1mKiX6KVaKUpUvNQHL9UnfVArXqofCoovfSgoPvTBBz/40AcLfvShICjY9EFREBT6oKBoDNoYExPNoo1KozExJkaNmD8zc9zZ8eScyznjnP0/MI6zZ2b2/GZmn+9be85mIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiC8D8GvG7AX8R6vU4BWA9gE8A+AJ0AtgK4AmAZwAKAWQCfAXiDA88BfAbgV68b8itBAtDrdRqAZwCqAHQD2AnACuByr+M0hFUAXwL4BMD7AD7wunFpQQKw6XW6CsALAHYAuBnA1l7H6QfLAGYBzAF4F8CrXjcuHUiADXqdBuAtALcBeAbAnV43bhNoApgG8C6A37xuXCqQACx6ndYB3APgBQC7et24K9AFYBjAawDe9rpxiZAA6/Q6qwDeAPAsgD29blwf6AawAuBVAK963bhYSIBFet0VAD8B0ARgp899Y+kDsAjgeQCrvW5cHCTAMr1eG4D3AewG8FCf+0oRArAI4G8A7wD4yevGuYMEWKDXXQVwDcBzAPZ63bdM0A3gLwDPAHjZ68a5gwRYp9ddA/ACgN0A7ve6b9WgB8A8gAcA/OR14+pBAizS660D+BmA+wHs97pvtYI9AEsAXgLwvNeNqwcJsEKvtwrgbQC3A9jvbd8mwB6AVQCPAnje68bVggRYpNddA/A2AAsA93vbt4mwB2AFwOMA0l43rhYkwCK93iqAlwHsB3Cv132bKHsAFgE8AeAZrxtXCxKgTq9/D8AHAH70uE+Zog8A/736IIDZ2A+O/fXvGvC+Ab8R7PUvBfAnAByF7AWA98b8/T943XghggSgp3+N677VIn4C8BfG/vofvG68EOH699jvv9Ziv93T8p/mHk973ZgfCHe9f/f061Dsb3vY3/Yw7u8veN2YHwjR3f9Bv9bC8v7fG/f3rXjfD8769399Xre7vG7MD4To7r+v78WwfP8vjvv7S973gzP/uD99r6e9bsyvBOm80p+f8+G8UfH97f7+mve94Cw6T6Y+8LoBvxcE9pW16O7/uL9vwfI+v/H9N3rdD86K9vW23+v7C8A9XjfkB0Lw/fSPrGvO8xrfT/v/l973gzPjPd3X33mO501eNuUHQvT+m/p7Nqxv0fP9v0L98/6Yv6866O9f0/f7TIDpY964XwjR+/VvN8P60t2A6P7e8vT9NP/Y0Pf7mOf9Rsz3/4Xp5+vG9YIu766vUv+OgnUf8yP6fv/Xf92YfggXvH/Xp7Uu/3D++UfG8759v6902Zp/CBe8v77X8/99pWvG805/V9p6Y964X9FpIOnS7p9G8/8vWPe/ov77B173Y0KigfR17pY6H86H87OPrP2Vv8UuXTMmHNI/vS7tfVpX947B0L+f7N/y938B8O8/fTf7OqfR6+vMv3vV0uVrfyB6vVvaL9Xl8p68BvLzC/78l+Y59jX/Fvp6p9Hr6fS5Wv/S86YvXfuaIPr5vP5f5/X/Oq991f8t6XmUv6t9vT3fX/X0PPlK19/m7+o8SFe6vO0fRHPfRz/V6S6v7X2F76v7X9Y987XInw+v6B+PjP1mHe310Ff5ur0N7f/7WnNf7nNPr/rW0/O7zT09r6u/W767676839Hdr9eY3zHdq9vP768297fS/9Xv8zN/6Yf5OfP+Yf8mfiPcP9TPx/63p8/9e/7f6W6T5f2ve9f9W5f/+d+v/N/7fuj7/D73vE0EAnO51AyIIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiD68D/iH9P7RRE7mAAAAABJRU5ErkJggg==";

const COLORS = {
  DARK_GREY: 'rgb(50, 50, 50)',
  RED: 'rgb(255, 0, 0)',
  BLUE: 'rgb(0, 0, 255)',
  GREEN: 'rgb(0, 200, 0)',
  PURPLE: 'rgb(160, 32, 240)',
  WHITE: 'rgb(255, 255, 255)',
  BLACK: 'rgb(0, 0, 0)',
  BRIGHT_YELLOW: 'rgb(255, 255, 100)',
  GOLD: 'rgb(255, 215, 0)',
  ORANGE: 'rgb(255, 165, 0)',
  LIGHT_BLUE: 'rgb(100, 150, 255)',
  CYAN: 'rgb(0, 255, 255)'
};

type GameState = 'LOADING' | 'FTC_SCREEN' | 'ALLIANCE_SELECT' | 'CONTROLS_1' | 'CONTROLS_2' | 'CONTROLS_3' | 'PLAYING' | 'PAUSED' | 'GAME_OVER' | 'PASSWORD_PROMPT' | 'YOUTUBE_OVERLAY';

const FtcDecodeGame: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>('LOADING');
  const [team, setTeam] = useState<'RED' | 'BLUE' | null>(null);
  const [score, setScore] = useState(0);
  const [remainingTime, setRemainingTime] = useState(75);
  const [inventory, setInventory] = useState<string[]>([]);
  const [currentMotif, setCurrentMotif] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [controlsTimer, setControlsTimer] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const collectorRef = useRef({ x: WINDOW_WIDTH / 2 - 25, y: WINDOW_HEIGHT / 2 - 25, width: 50, height: 50, speed: 8 });
  const keysPressed = useRef<Set<string>>(new Set());
  const collectiblesRef = useRef<{ x: number, y: number, radius: number, type: string }[]>([]);
  const requestRef = useRef<number>(0);
  const startTimeRef = useRef<number>(0);

  const patterns = ["GPP", "PPG", "PGP"];
  const borderSize = 160;
  const redBase = { x: borderSize + 100, y: WINDOW_HEIGHT - borderSize - 100, width: 100, height: 100 };
  const blueBase = { x: WINDOW_WIDTH - borderSize - 200, y: WINDOW_HEIGHT - borderSize - 100, width: 100, height: 100 };

  // Initialize Game Logic
  useEffect(() => {
    // Start with loading bar animation
    const loadInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(loadInterval);
          setGameState('FTC_SCREEN');
          return 100;
        }
        return prev + 1;
      });
    }, 50);

    return () => clearInterval(loadInterval);
  }, []);

  // Controls auto-advance timers
  useEffect(() => {
    let interval: any;
    if (gameState === 'CONTROLS_1' || gameState === 'CONTROLS_2' || gameState === 'CONTROLS_3') {
      const duration = gameState === 'CONTROLS_1' ? 4 : gameState === 'CONTROLS_2' ? 3 : 2;
      setControlsTimer(duration);
      interval = setInterval(() => {
        setControlsTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            if (gameState === 'CONTROLS_1') setGameState('CONTROLS_2');
            else if (gameState === 'CONTROLS_2') setGameState('CONTROLS_3');
            else {
              setGameState('PLAYING');
              startTimeRef.current = Date.now();
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameState]);

  // Main Timer Effect
  useEffect(() => {
    let interval: any;
    if (gameState === 'PLAYING' && remainingTime > 0) {
      interval = setInterval(() => setRemainingTime(t => t - 1), 1000);
    } else if (remainingTime === 0 && gameState === 'PLAYING') {
      endGame();
    }
    return () => clearInterval(interval);
  }, [gameState, remainingTime]);

  // Artifact Spawning
  const setupCollectibles = () => {
    const items: { x: number, y: number, radius: number, type: string }[] = [];
    const radius = 20;

    // Right side
    const patternsRight = [["G", "P", "P"], ["P", "G", "P"], ["P", "P", "G"]];
    const baseXRight = WINDOW_WIDTH - borderSize + 40;
    const baseYRight = WINDOW_HEIGHT - borderSize - 60;
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        items.push({ x: baseXRight + c * 55, y: baseYRight - r * 55, radius, type: patternsRight[r][c] });
      }
    }

    // Left side
    const patternsLeft = [["P", "P", "G"], ["P", "G", "P"], ["G", "P", "P"]];
    const baseXLeft = 40;
    const baseYLeft = WINDOW_HEIGHT - borderSize - 60;
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        items.push({ x: baseXLeft + c * 55, y: baseYLeft - r * 55, radius, type: patternsLeft[r][c] });
      }
    }
    collectiblesRef.current = items;
  };

  const endGame = () => {
    setGameState('GAME_OVER');
    setScore(prev => {
      let final = prev + 18; // Default bonus
      const collector = collectorRef.current;
      const base = team === 'RED' ? redBase : blueBase;
      const inBase = collector.x < base.x + base.width && collector.x + collector.width > base.x && collector.y < base.y + base.height && collector.y + collector.height > base.y;
      if (inBase) final += 10;
      return final;
    });
  };

  const selectAlliance = (selectedTeam: 'RED' | 'BLUE') => {
    setTeam(selectedTeam);
    setCurrentMotif(patterns[Math.floor(Math.random() * patterns.length)]);
    setupCollectibles();
    setGameState('CONTROLS_1');
  };

  const handleRestart = () => {
    setScore(0);
    setRemainingTime(75);
    setInventory([]);
    collectorRef.current = { x: WINDOW_WIDTH / 2 - 25, y: WINDOW_HEIGHT / 2 - 25, width: 50, height: 50, speed: 8 };
    setupCollectibles();
    setCurrentMotif(patterns[Math.floor(Math.random() * patterns.length)]);
    setGameState('PLAYING');
    startTimeRef.current = Date.now();
  };

  // Input Handling
  useEffect(() => {
    const down = (e: KeyboardEvent) => keysPressed.current.add(e.key.toLowerCase());
    const up = (e: KeyboardEvent) => keysPressed.current.delete(e.key.toLowerCase());
    const tab = (e: KeyboardEvent) => {
      if (e.key === 'Tab' && gameState === 'PLAYING') {
        e.preventDefault();
        setGameState('PAUSED');
      } else if (e.key === 'Tab' && gameState === 'PAUSED') {
        e.preventDefault();
        setGameState('PLAYING');
      }
      if (e.key.toLowerCase() === 'p' && (gameState === 'LOADING' || gameState === 'ALLIANCE_SELECT')) {
        setGameState('PASSWORD_PROMPT');
      }
    };

    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('keydown', tab);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('keydown', tab);
    };
  }, [gameState]);

  // Update Game Logic
  const update = () => {
    if (gameState !== 'PLAYING') return;

    const collector = collectorRef.current;
    if (keysPressed.current.has('arrowleft') || keysPressed.current.has('a')) collector.x -= collector.speed;
    if (keysPressed.current.has('arrowright') || keysPressed.current.has('d')) collector.x += collector.speed;
    if (keysPressed.current.has('arrowup') || keysPressed.current.has('w')) collector.y -= collector.speed;
    if (keysPressed.current.has('arrowdown') || keysPressed.current.has('s')) collector.y += collector.speed;

    collector.x = Math.max(0, Math.min(collector.x, WINDOW_WIDTH - collector.width));
    collector.y = Math.max(0, Math.min(collector.y, WINDOW_HEIGHT - collector.height));

    // Artifact Collection
    for (let i = collectiblesRef.current.length - 1; i >= 0; i--) {
      const art = collectiblesRef.current[i];
      const closestX = Math.max(collector.x, Math.min(art.x, collector.x + collector.width));
      const closestY = Math.max(collector.y, Math.min(art.y, collector.y + collector.height));
      const distSq = (art.x - closestX) ** 2 + (art.y - closestY) ** 2;

      if (distSq < art.radius ** 2 && inventory.length < 3) {
        const type = art.type;
        setInventory(prev => [...prev, type]);
        collectiblesRef.current.splice(i, 1);
      }
    }

    // Scoring Zone (Triangles)
    const triangleSize = 180;
    let inZone = false;
    if (team === 'BLUE') inZone = collector.x < triangleSize && collector.y < triangleSize;
    else inZone = collector.x + collector.width > WINDOW_WIDTH - triangleSize && collector.y < triangleSize;

    if (inZone && inventory.length > 0) {
      const currentPattern = inventory.join('');
      setScore(prev => prev + (currentPattern === currentMotif ? 15 : 9));
      
      // Respawn inventory items
      const newItems = inventory.map(type => {
        const side = Math.random() < 0.5 ? 'LEFT' : 'RIGHT';
        const zone = side === 'LEFT' ? { x: 0, y: WINDOW_HEIGHT - borderSize, w: borderSize, h: borderSize } : { x: WINDOW_WIDTH - borderSize, y: WINDOW_HEIGHT - borderSize, w: borderSize, h: borderSize };
        const radius = 20;
        return {
          type,
          radius,
          x: zone.x + 25 + radius + Math.random() * (zone.w - radius * 2 - 50),
          y: zone.y + 25 + radius + Math.random() * (zone.h - radius * 2 - 50)
        };
      });
      collectiblesRef.current.push(...newItems);
      setInventory([]);
    }

    draw();
    requestRef.current = requestAnimationFrame(update);
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = COLORS.BLACK;
    ctx.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

    if (gameState === 'PLAYING' || gameState === 'PAUSED' || gameState === 'GAME_OVER') {
      const triangleSize = 180;
      // Blue Triangle
      ctx.fillStyle = COLORS.BLUE;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(triangleSize, 0); ctx.lineTo(0, triangleSize); ctx.closePath(); ctx.fill();
      // Red Triangle
      ctx.fillStyle = COLORS.RED;
      ctx.beginPath(); ctx.moveTo(WINDOW_WIDTH, 0); ctx.lineTo(WINDOW_WIDTH - triangleSize, 0); ctx.lineTo(WINDOW_WIDTH, triangleSize); ctx.closePath(); ctx.fill();

      // Squares
      ctx.fillStyle = COLORS.DARK_GREY;
      ctx.fillRect(0, WINDOW_HEIGHT - borderSize, borderSize, borderSize);
      ctx.strokeStyle = COLORS.WHITE; ctx.lineWidth = 4; ctx.strokeRect(0, WINDOW_HEIGHT - borderSize, borderSize, borderSize);
      ctx.fillRect(WINDOW_WIDTH - borderSize, WINDOW_HEIGHT - borderSize, borderSize, borderSize);
      ctx.strokeRect(WINDOW_WIDTH - borderSize, WINDOW_HEIGHT - borderSize, borderSize, borderSize);

      // Bases
      ctx.fillStyle = COLORS.RED;
      ctx.fillRect(redBase.x, redBase.y, redBase.width, redBase.height);
      ctx.strokeStyle = COLORS.WHITE; ctx.lineWidth = 3; ctx.strokeRect(redBase.x, redBase.y, redBase.width, redBase.height);
      ctx.fillStyle = COLORS.BLUE;
      ctx.fillRect(blueBase.x, blueBase.y, blueBase.width, blueBase.height);
      ctx.strokeRect(blueBase.x, blueBase.y, blueBase.width, blueBase.height);

      // Collectibles
      collectiblesRef.current.forEach(art => {
        ctx.fillStyle = art.type === 'G' ? COLORS.GREEN : COLORS.PURPLE;
        ctx.beginPath(); ctx.arc(art.x, art.y, art.radius, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = COLORS.WHITE; ctx.lineWidth = 2; ctx.stroke();
      });

      // Collector
      const collector = collectorRef.current;
      ctx.fillStyle = COLORS.WHITE;
      ctx.fillRect(collector.x, collector.y, collector.width, collector.height);
      ctx.strokeStyle = COLORS.DARK_GREY; ctx.lineWidth = 3; ctx.strokeRect(collector.x, collector.y, collector.width, collector.height);
      
      // Team Indicator
      ctx.fillStyle = team === 'RED' ? COLORS.RED : COLORS.BLUE;
      ctx.beginPath(); ctx.arc(collector.x + 25, collector.y + 25, 12, 0, Math.PI * 2); ctx.fill();

      // Triangle Zone Glow
      if (inventory.length > 0) {
        ctx.strokeStyle = team === 'RED' ? COLORS.RED : COLORS.BLUE;
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(collector.x + 25, collector.y + 25, 60, 0, Math.PI * 2); ctx.stroke();
      }
    }
  };

  useEffect(() => {
    if (gameState === 'PLAYING') {
      requestRef.current = requestAnimationFrame(update);
    } else {
      cancelAnimationFrame(requestRef.current);
    }
    return () => cancelAnimationFrame(requestRef.current);
  }, [gameState, inventory, team, currentMotif]);

  return (
    <div className="w-[900px] h-[600px] bg-black relative font-sans overflow-hidden select-none border-2 border-white">
      <canvas ref={canvasRef} width={WINDOW_WIDTH} height={WINDOW_HEIGHT} className="block cursor-none" />

      {/* HUD */}
      {gameState === 'PLAYING' && (
        <div className="absolute top-5 left-5 text-yellow-300 font-bold space-y-2 pointer-events-none drop-shadow-lg">
          <div className="text-2xl">Score: {score}</div>
          <div className="text-2xl">Time: {remainingTime}s</div>
          <div className="text-xl">Inventory: {inventory.filter(i => i === 'G').length}G, {inventory.filter(i => i === 'P').length}P</div>
          <div className="text-xl">Motif: {currentMotif}</div>
          <div className="text-xl">Team: {team}</div>
          {inventory.length > 0 && (
             <div className={`text-xl font-black ${team === 'RED' ? 'text-red-500' : 'text-blue-500'} animate-pulse`}>
                Go to {team} triangle to score!
             </div>
          )}
        </div>
      )}

      {/* Overlays */}
      <AnimatePresence>
        {gameState === 'LOADING' && (
          <motion.div exit={{ opacity: 0 }} className="absolute inset-0 bg-black flex flex-col items-center justify-center p-10 z-50">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-48 h-48 mb-10"
            >
               <img src={TEAM_LOGO} alt="Loading Team Logo" className="w-full h-full object-contain drop-shadow-[0_0_20px_rgba(234,179,8,0.5)]" />
            </motion.div>
            <h1 className="text-6xl font-black italic text-yellow-500 mb-8 tracking-tighter drop-shadow-[0_4px_4px_rgba(100,80,0,0.7)]">G-FORCE 19013</h1>
            <div className="w-[400px] h-4 bg-zinc-800 border border-white/20 rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }} 
                 animate={{ width: `${loadingProgress}%` }}
                 className="h-full bg-yellow-500" 
               />
            </div>
            <div className="mt-4 text-yellow-400 font-bold text-lg tracking-widest uppercase">Loading... {loadingProgress}%</div>
            <div className="mt-8 text-yellow-200/50 text-xs font-bold uppercase tracking-widest">Press 'P' for Developer Access</div>
          </motion.div>
        )}

        {gameState === 'FTC_SCREEN' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-10 z-40">
             <div 
               onClick={() => setGameState('ALLIANCE_SELECT')}
               className="w-[600px] h-[400px] bg-zinc-900 rounded-[30px] border-4 border-yellow-500/50 flex flex-col items-center justify-center cursor-pointer hover:scale-105 transition-transform group"
             >
                <img src={TEAM_LOGO} alt="Start Screen Logo" className="w-40 h-40 mb-8 group-hover:rotate-12 transition-transform duration-500" />
                <h2 className="text-7xl font-black text-white italic drop-shadow-lg tracking-tighter">FTC DECODE</h2>
                <div className="mt-6 flex items-center gap-2 text-yellow-500 font-bold tracking-widest uppercase">
                   <Play size={20} className="fill-yellow-500" /> Click to Enter
                </div>
             </div>
             <p className="mt-8 text-yellow-100/40 text-sm font-bold uppercase tracking-widest">Authorized by G-Force 19013</p>
          </motion.div>
        )}

        {gameState === 'ALLIANCE_SELECT' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-10 z-30 text-center">
             <h2 className="text-6xl font-black italic text-yellow-500 mb-12 drop-shadow-md">SELECT YOUR ALLIANCE</h2>
             <div className="flex gap-10">
                <button onClick={() => selectAlliance('RED')} className="w-52 h-52 bg-red-600 border-4 border-white rounded-3xl text-4xl font-black hover:scale-110 transition-transform shadow-xl">RED</button>
                <button onClick={() => selectAlliance('BLUE')} className="w-52 h-52 bg-blue-600 border-4 border-white rounded-3xl text-4xl font-black hover:scale-110 transition-transform shadow-xl">BLUE</button>
             </div>
             <p className="mt-12 text-yellow-200 font-bold uppercase tracking-widest">Awaiting Deployment Input...</p>
          </motion.div>
        )}

        {gameState === 'CONTROLS_1' && (
          <motion.div className="absolute inset-0 bg-zinc-900/95 flex flex-col items-center justify-center p-10 z-20">
             <h2 className="text-5xl font-black italic text-yellow-400 mb-8 uppercase">Movement Interface</h2>
             <div className="w-full max-w-2xl bg-black/60 border-2 border-yellow-500 p-8 rounded-3xl space-y-4">
                {['W / UP ARROW → UP', 'A / LEFT ARROW → LEFT', 'S / DOWN ARROW → DOWN', 'D / RIGHT ARROW → RIGHT'].map((c, i) => (
                  <div key={i} className="flex justify-between p-4 bg-zinc-800 rounded-xl border border-yellow-500/20 font-black text-2xl uppercase">
                    <span className="text-white">{c.split('→')[0]}</span>
                    <span className="text-yellow-500">{c.split('→')[1]}</span>
                  </div>
                ))}
             </div>
             <div className="mt-10 text-yellow-200 text-xl font-bold uppercase tracking-[0.3em]">Synching in: {controlsTimer}s</div>
          </motion.div>
        )}

        {/* ... (rest of the overlays remain standard with consistent text) */}
        
        {gameState === 'CONTROLS_2' && (
          <motion.div className="absolute inset-0 bg-zinc-900/95 flex flex-col items-center justify-center p-10 z-20">
             <h2 className="text-5xl font-black italic text-yellow-400 mb-8 uppercase text-center">System Controls</h2>
             <div className="w-full max-w-2xl bg-black/60 border-2 border-yellow-500 p-8 rounded-3xl">
                <div className="flex justify-between p-6 bg-zinc-800 rounded-xl border border-yellow-500/20 font-black text-3xl uppercase">
                  <span className="text-white">TAB KEY</span>
                  <span className="text-yellow-500">PAUSE COMMS</span>
                </div>
             </div>
             <div className="mt-10 text-yellow-200 text-xl font-bold uppercase tracking-[0.3em]">Deploying in: {controlsTimer}s</div>
          </motion.div>
        )}

        {gameState === 'CONTROLS_3' && (
          <motion.div className="absolute inset-0 bg-zinc-900/95 flex flex-col items-center justify-center p-10 z-20">
             <h2 className="text-5xl font-black italic text-yellow-400 mb-6 uppercase">Mission Parameters</h2>
             <div className="w-full max-w-3xl grid grid-cols-2 gap-4">
                {[
                  { t: 'OBJECTIVE', d: 'Collect artifacts and match patterns' },
                  { t: 'ARTIFACTS', d: 'Collect G (Gold) and P (Purple)' },
                  { t: 'PATTERNS', d: 'Match GPP, PPG, or PGP' },
                  { t: 'SCORING', d: '+15 Correct Pattern, +9 Wrong' },
                  { t: 'INVENTORY', d: 'Carry max 3 artifacts at once' },
                  { t: 'TIME LIMIT', d: '75 seconds to score points' }
                ].map((item, idx) => (
                  <div key={idx} className="bg-black/60 border border-yellow-500/30 p-4 rounded-xl">
                    <div className="text-yellow-500 font-black text-lg mb-1 tracking-wider uppercase">{item.t}</div>
                    <div className="text-white font-bold text-sm">{item.d}</div>
                  </div>
                ))}
             </div>
             <div className="mt-8 text-yellow-200 text-2xl font-black italic tracking-widest">INITIALIZING GAME IN: {controlsTimer}s</div>
          </motion.div>
        )}

        {gameState === 'PAUSED' && (
          <motion.div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center p-10 z-50">
             <h2 className="text-7xl font-black italic text-yellow-400 mb-10 drop-shadow-md">COMMS OFFLINE</h2>
             <div className="flex flex-wrap gap-4 justify-center max-w-2xl">
                <button onClick={() => setGameState('PLAYING')} className="px-10 py-4 bg-green-600 border-2 border-white rounded-2xl font-black text-xl hover:scale-105 transition-transform">RESUME</button>
                <button onClick={handleRestart} className="px-10 py-4 bg-yellow-500 border-2 border-white rounded-2xl font-black text-xl hover:scale-105 transition-transform text-black">REBOOT</button>
                <button onClick={() => setGameState('ALLIANCE_SELECT')} className="px-10 py-4 bg-blue-600 border-2 border-white rounded-2xl font-black text-xl hover:scale-105 transition-transform">NEW TEAM</button>
                <button onClick={() => setGameState('LOADING')} className="px-10 py-4 bg-red-600 border-2 border-white rounded-2xl font-black text-xl hover:scale-105 transition-transform">ABORT</button>
             </div>
          </motion.div>
        )}

        {gameState === 'GAME_OVER' && (
          <motion.div className="absolute inset-0 bg-black flex flex-col items-center justify-center p-10 z-50 text-center">
             <div className="w-40 h-40 mb-6">
                <img src={TEAM_LOGO} alt="Game Over Logo" className="w-full h-full object-contain grayscale opacity-50" />
             </div>
             <h2 className="text-8xl font-black italic text-yellow-500 mb-4 tracking-tighter">MISSION COMPLETE</h2>
             <div className="text-5xl font-black text-yellow-200 mb-4 italic">TOTAL SYNC: {score}</div>
             <div className="text-2xl font-black text-yellow-500/60 mb-12 uppercase tracking-[0.5em]">+18 Bonus Points Logged</div>
             <div className="flex gap-6">
                <button onClick={handleRestart} className="px-12 py-5 bg-green-600 border-2 border-white rounded-2xl font-black text-2xl uppercase shadow-2xl hover:scale-105 transition-transform">RE-RUN</button>
                <button onClick={() => setGameState('ALLIANCE_SELECT')} className="px-12 py-5 bg-blue-600 border-2 border-white rounded-2xl font-black text-2xl uppercase shadow-2xl hover:scale-105 transition-transform">DE-BRIEF</button>
             </div>
          </motion.div>
        )}

        {gameState === 'PASSWORD_PROMPT' && (
          <motion.div className="absolute inset-0 bg-zinc-900/95 flex items-center justify-center p-10 z-[60]">
             <div className="bg-black border-4 border-yellow-500 p-10 rounded-[30px] w-full max-w-md shadow-2xl text-center">
                <img src={TEAM_LOGO} alt="Secure Logo" className="w-20 h-20 mx-auto mb-6" />
                <h3 className="text-4xl font-black italic text-yellow-400 mb-6 uppercase tracking-tighter">Secure Channel</h3>
                <p className="text-yellow-100/60 mb-6 font-bold uppercase text-xs tracking-widest">Authentication Required for Uplink</p>
                <input 
                  type="password" 
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                       if (passwordInput.toLowerCase() === 'password') setGameState('YOUTUBE_OVERLAY');
                       else setPasswordInput('');
                    }
                  }}
                  className="w-full p-4 bg-zinc-900 text-yellow-500 text-xl font-black rounded-xl mb-8 outline-none border-2 border-yellow-500/20 focus:border-yellow-500 transition-colors"
                  placeholder="ENTRY_CODE"
                />
                <div className="flex gap-4 justify-center">
                   <button 
                     onClick={() => {
                       if (passwordInput.toLowerCase() === 'password') setGameState('YOUTUBE_OVERLAY');
                       else setPasswordInput('');
                     }} 
                     className="px-8 py-3 bg-yellow-500 text-black rounded-xl font-black uppercase"
                   >
                    SYNC
                   </button>
                   <button onClick={() => setGameState('LOADING')} className="px-8 py-3 bg-zinc-800 text-white rounded-xl font-black uppercase">ABORT</button>
                </div>
             </div>
          </motion.div>
        )}

        {gameState === 'YOUTUBE_OVERLAY' && (
          <motion.div className="absolute inset-0 bg-black flex flex-col items-center justify-center p-10 z-[70]">
             <h2 className="text-4xl font-black italic text-yellow-400 mb-6 uppercase tracking-tighter">Encrypted Intel Decrypted</h2>
             <div className="relative w-full max-w-4xl aspect-video rounded-2xl overflow-hidden border-4 border-yellow-500 shadow-2xl">
                <iframe 
                  className="absolute inset-0 w-full h-full"
                  src="https://www.youtube.com/embed/xvFZjo5PgG0?autoplay=1" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowFullScreen
                />
             </div>
             <button onClick={() => setGameState('LOADING')} className="mt-10 px-12 py-4 bg-red-600 border-2 border-white rounded-2xl font-black text-2xl uppercase hover:scale-105 transition-transform shadow-xl">TERMINATE FEED</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FtcDecodeGame;
