
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { Minus, Plus, AlertTriangle, ShieldAlert, Trophy } from 'lucide-react';

interface AllianceData {
  art: number;
  ov: number;
  pat: number;
  foulsReceived: number;
}

const FtcScorer: React.FC = () => {
  const [red, setRed] = useState<AllianceData>({ art: 0, ov: 0, pat: 0, foulsReceived: 0 });
  const [blue, setBlue] = useState<AllianceData>({ art: 0, ov: 0, pat: 0, foulsReceived: 0 });

  const calcScore = (data: AllianceData) => {
    return data.art * 3 + data.ov * 1 + data.pat * 2 + data.foulsReceived;
  };

  const redScore = calcScore(red);
  const blueScore = calcScore(blue);

  const getRP = (score: number, opponentScore: number) => {
    if (score > opponentScore) return 3;
    if (score === opponentScore) return 1;
    return 0;
  };

  const redRP = getRP(redScore, blueScore);
  const blueRP = getRP(blueScore, redScore);

  const updateVal = (alliance: 'red' | 'blue', key: keyof AllianceData, delta: number) => {
    const setter = alliance === 'red' ? setRed : setBlue;
    setter(prev => ({
      ...prev,
      [key]: Math.max(0, prev[key] + delta)
    }));
  };

  const addFoul = (committingAlliance: 'red' | 'blue', pts: number) => {
    // Fouls give points to the OTHER alliance
    const victimSetter = committingAlliance === 'red' ? setBlue : setRed;
    victimSetter(prev => ({
      ...prev,
      foulsReceived: prev.foulsReceived + pts
    }));
  };

  const ScoreCard = ({ 
    alliance, 
    data, 
    score, 
    rp, 
    colorClass 
  }: { 
    alliance: string, 
    data: AllianceData, 
    score: number, 
    rp: number, 
    colorClass: string 
  }) => (
    <div className={`p-8 rounded-3xl border-2 bg-black/40 backdrop-blur-xl transition-all duration-500 ${colorClass === 'red' ? 'border-red-500/30 shadow-[0_0_30px_rgba(239,68,68,0.1)]' : 'border-blue-500/30 shadow-[0_0_30px_rgba(59,130,246,0.1)]'}`}>
      <div className="flex justify-between items-center mb-8">
        <h3 className={`text-3xl font-black italic tracking-tighter uppercase ${colorClass === 'red' ? 'text-red-500' : 'text-blue-500'}`}>
          {alliance} Alliance
        </h3>
        <div className="flex items-center gap-2 px-4 py-1 rounded-full bg-white/5 border border-white/10">
          <Trophy size={14} className="text-yellow-500" />
          <span className="text-xs font-black tracking-widest text-yellow-500">RP: {rp}</span>
        </div>
      </div>

      <div className="space-y-6">
        {[
          { label: 'Artifacts', key: 'art' as keyof AllianceData, weight: '3pts' },
          { label: 'Overflow', key: 'ov' as keyof AllianceData, weight: '1pt' },
          { label: 'Pattern Matches', key: 'pat' as keyof AllianceData, weight: '2pts' },
        ].map((item) => (
          <div key={item.key} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
            <div>
              <div className="font-bold text-white uppercase text-sm tracking-widest">{item.label}</div>
              <div className="text-[10px] text-gray-500 font-black uppercase tracking-[0.2em]">{item.weight}</div>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => updateVal(colorClass as any, item.key, -1)}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
              >
                <Minus size={18} />
              </button>
              <span className="text-2xl font-black italic min-w-[30px] text-center">{data[item.key]}</span>
              <button 
                onClick={() => updateVal(colorClass as any, item.key, 1)}
                className="w-10 h-10 rounded-xl bg-yellow-500 text-black flex items-center justify-center hover:bg-white transition-colors"
              >
                <Plus size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 pt-8 border-t border-white/10 flex justify-between items-end">
        <div className="flex flex-col">
          <span className="text-[10px] font-black tracking-[0.3em] text-gray-500 uppercase">Current Score</span>
          <span className={`text-6xl font-black italic tracking-tighter ${colorClass === 'red' ? 'text-red-500' : 'text-blue-500'}`}>
            {score}
          </span>
        </div>
        {data.foulsReceived > 0 && (
          <div className="text-right">
            <span className="text-[10px] font-black tracking-[0.3em] text-green-500 uppercase">Foul Bonus</span>
            <div className="text-xl font-black text-green-500">+{data.foulsReceived}</div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="container mx-auto px-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <ScoreCard 
          alliance="Red" 
          data={red} 
          score={redScore} 
          rp={redRP} 
          colorClass="red" 
        />
        <ScoreCard 
          alliance="Blue" 
          data={blue} 
          score={blueScore} 
          rp={blueRP} 
          colorClass="blue" 
        />
      </div>

      {/* Fouls Section */}
      <div className="p-8 rounded-[2.5rem] bg-gradient-to-br from-zinc-900 to-black border border-white/10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-yellow-500">
              <AlertTriangle size={32} />
            </div>
            <div>
              <h4 className="text-2xl font-black italic uppercase tracking-tight">System Violations</h4>
              <p className="text-gray-400 text-sm font-medium">Fouls awarded to the opposing alliance registry.</p>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4">
            <button 
              onClick={() => addFoul('red', 10)}
              className="px-6 py-3 rounded-xl border border-red-500/50 text-red-500 font-black text-xs uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
            >
              RED MINOR (-10)
            </button>
            <button 
              onClick={() => addFoul('red', 30)}
              className="px-6 py-3 rounded-xl bg-red-600 text-white font-black text-xs uppercase tracking-widest hover:bg-red-500 transition-all"
            >
              RED MAJOR (-30)
            </button>
            <div className="w-px h-10 bg-white/10 hidden md:block" />
            <button 
              onClick={() => addFoul('blue', 10)}
              className="px-6 py-3 rounded-xl border border-blue-500/50 text-blue-500 font-black text-xs uppercase tracking-widest hover:bg-blue-500 hover:text-white transition-all"
            >
              BLUE MINOR (-10)
            </button>
            <button 
              onClick={() => addFoul('blue', 30)}
              className="px-6 py-3 rounded-xl bg-blue-600 text-white font-black text-xs uppercase tracking-widest hover:bg-blue-500 transition-all"
            >
              BLUE MAJOR (-30)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FtcScorer;
