
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { 
  Instagram, 
  Mail, 
  ChevronRight, 
  Gamepad2, 
  Send,
  Play,
  X,
  Menu,
  Users,
  Calculator,
  Youtube,
  Minus,
  Plus,
  AlertTriangle,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- CONSTANTS ---
const TEAM_LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFmklEQVR4nO2dW0hcVxjH/6MmdUisMTYmGjE1mKiX6KVaKUpUvNQHL9UnfVArXqofCoovfSgoPvTBBz/40AcLfvShICjY9EFREBT6oKBoDNoYExPNoo1KozExJkaNmD8zc9zZ8eScyznjnP0/MI6zZ2b2/GZmn+9be85mIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiC8D8GvG7AX8R6vU4BWA9gE8A+AJ0AtgK4AmAZwAKAWQCfAXiDA88BfAbgV68b8itBAtDrdRqAZwCqAHQD2AnACuByr+M0hFUAXwL4BMD7AD7wunFpQQKw6XW6CsALAHYAuBnA1l7H6QfLAGYBzAF4F8CrXjcuHUiADXqdBuAtALcBeAbAnV43bhNoApgG8C6A37xuXCqQACx6ndYB3APgBQC7+t24K9AFYBjAawDe9rpxiZAA6/Q6qwDeAPAsgD29blwf6AawAuBVAK963bhYSIBFet0VAD8B0ARgp899Y+kDsAjgeQCrvW5cHCTAMr1eG4D3AewG8FCf+0oRArAI4G8A7wD4yevGuYMEWKDXXQVwDcBzAPZ63bdM0A3gLwDPAHjZ68a5gwRYp9ddA/ACgN0A7ve6b9WgB8A8gAcA/OR14+pBAizS660D+BmA+wHs97pvtYI9AEsAXgLwvNeNqwcJsEKvtwrgbQC3A9jvbd8mwB6AVQCPAnje68bVggRYpNddA/A2AAsA93vbt4mwB2AFwOMA0l43rhYkwCK93iqAlwHsB3Cv132bKHsAFgE8AeAZrxtXCxKgTq9/D8AHAH70uE+Zog8A/736IIDZ2A+O/fXvGvC+Ab8R7PUvBfAnAByF7AWA98b8/T943XghggSgp3+N677VIn4C8BfG/vofvG68EOH699jvv9Ziv93T8p/mHk973ZgfCHe9f/f061Dsb3vY3/Yw7u8veN2YHwjR3f9Bv9bC8v7fG/f3rXjfD8769399Xre7vG7MD4To7r+v78WwfP8vjvv7S973gzP/uD99r6e9bsyvBOm80p+f8+G8UfH97f7+mve94Cw6T6Y+8LoBvxcE9pW16O7/uL9vwfI+v/H9N3rdD86K9vW23+v7C8A9XjfkB0Lw/fSPrGvO8xrfT/v/l973gzPjPd3X33mO501eNuUHQvT+m/p7Nqxv0fP9v0L98/6Yv6866O9f0/f7TIDpY964XwjR+/VvN8P60t2A6P7e8vT9NP/Y0Pf7mOf9Rsz3/4Xp5+vG9YIu766vUv+OgnUf8yP6fv/Xf92YfggXvH/Xp7Uu/3D++UfG8759v6902Zp/CBe8v77X8/99pWvG805/V9p6Y964X9FpIOnS7p9G8/8vWPe/ov77B173Y0KigfR17pY6H86H87OPrP2Vv8UuXTMmHNI/vS7tfVpX947B0L+f7N/y938B8O8/fTf7OqfR6+vMv3vV0uVrfyB6vVvaL9Xl8p68BvLzC/78l+Y59jX/Fvp6p9Hr6fS5Wv/S86YvXfuaIPr5vP5f5/X/Oq991f8t6XmUv6t9vT3fX/X0PPlK19/m7+o8SFe6vO0fRHPfRz/V6S6v7X2F76v7X9Y987XInw+v6B+PjP1mHe310Ff5ur0N7f/7WnNf7nNPr/rW0/O7zT09r6u/W767676839Hdr9eY3zHdq9vP768297fS/9Xv8zN/6Yf5OfP+Yf8mfiPcP9TPx/63p8/9e/7f6W6T5f2ve9f9W5f/+d+v/N/7fuj7/D73vE0EAnO51AyIIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiD68D/iH9P7RRE7mAAAAABJRU5ErkJggg==";

const GAME_COLORS = {
  RED: 'rgb(255, 0, 0)',
  BLUE: 'rgb(0, 0, 255)',
  GREEN: 'rgb(0, 200, 0)',
  PURPLE: 'rgb(160, 32, 240)',
  WHITE: 'rgb(255, 255, 255)',
  BLACK: 'rgb(0, 0, 0)',
  YELLOW: 'rgb(234, 179, 8)',
  DARK_GREY: 'rgb(39, 39, 42)'
};

// --- SUB-COMPONENTS ---

const FtcDecodeGame: React.FC = () => {
  const [gameState, setGameState] = useState<'LOADING' | 'FTC_SCREEN' | 'ALLIANCE_SELECT' | 'CONTROLS' | 'PLAYING' | 'PAUSED' | 'GAME_OVER'>('LOADING');
  const [team, setTeam] = useState<'RED' | 'BLUE' | null>(null);
  const [score, setScore] = useState(0);
  const [remainingTime, setRemainingTime] = useState(75);
  const [inventory, setInventory] = useState<string[]>([]);
  const [currentMotif, setCurrentMotif] = useState('');
  const [loadingProgress, setLoadingProgress] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const collectorRef = useRef({ x: 425, y: 275, width: 50, height: 50, speed: 7 });
  const keysPressed = useRef<Set<string>>(new Set());
  const collectiblesRef = useRef<{ x: number, y: number, radius: number, type: string }[]>([]);
  const requestRef = useRef<number>(0);

  const WINDOW_WIDTH = 900;
  const WINDOW_HEIGHT = 600;
  const borderSize = 160;
  const triangleSize = 180;
  const redBase = { x: borderSize + 100, y: WINDOW_HEIGHT - borderSize - 100, width: 100, height: 100 };
  const blueBase = { x: WINDOW_WIDTH - borderSize - 200, y: WINDOW_HEIGHT - borderSize - 100, width: 100, height: 100 };

  useEffect(() => {
    if (gameState === 'LOADING') {
      const interval = setInterval(() => {
        setLoadingProgress(p => {
          if (p >= 100) { clearInterval(interval); setGameState('FTC_SCREEN'); return 100; }
          return p + 2;
        });
      }, 30);
      return () => clearInterval(interval);
    }
  }, [gameState]);

  useEffect(() => {
    let interval: any;
    if (gameState === 'PLAYING' && remainingTime > 0) {
      interval = setInterval(() => setRemainingTime(t => t - 1), 1000);
    } else if (remainingTime === 0 && gameState === 'PLAYING') {
      setGameState('GAME_OVER');
    }
    return () => clearInterval(interval);
  }, [gameState, remainingTime]);

  const setupCollectibles = () => {
    const items = [];
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        items.push({ x: 60 + c * 50, y: 350 + r * 50, radius: 18, type: Math.random() > 0.5 ? 'G' : 'P' });
        items.push({ x: 700 + c * 50, y: 350 + r * 50, radius: 18, type: Math.random() > 0.5 ? 'G' : 'P' });
      }
    }
    collectiblesRef.current = items;
  };

  const update = () => {
    if (gameState !== 'PLAYING') return;
    const c = collectorRef.current;
    if (keysPressed.current.has('w') || keysPressed.current.has('arrowup')) c.y -= c.speed;
    if (keysPressed.current.has('s') || keysPressed.current.has('arrowdown')) c.y += c.speed;
    if (keysPressed.current.has('a') || keysPressed.current.has('arrowleft')) c.x -= c.speed;
    if (keysPressed.current.has('d') || keysPressed.current.has('arrowright')) c.x += c.speed;

    c.x = Math.max(0, Math.min(c.x, WINDOW_WIDTH - c.width));
    c.y = Math.max(0, Math.min(c.y, WINDOW_HEIGHT - c.height));

    collectiblesRef.current.forEach((item, idx) => {
      const dist = Math.sqrt((item.x - (c.x + 25))**2 + (item.y - (c.y + 25))**2);
      if (dist < 40 && inventory.length < 3) {
        setInventory(prev => [...prev, item.type]);
        collectiblesRef.current.splice(idx, 1);
      }
    });

    const inZone = team === 'BLUE' ? (c.x < triangleSize && c.y < triangleSize) : (c.x > WINDOW_WIDTH - triangleSize - 50 && c.y < triangleSize);
    if (inZone && inventory.length > 0) {
      setScore(s => s + (inventory.length * 5));
      setInventory([]);
      if (collectiblesRef.current.length < 5) setupCollectibles();
    }

    draw();
    requestRef.current = requestAnimationFrame(update);
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    
    // Scoring Zones
    ctx.fillStyle = GAME_COLORS.BLUE; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(triangleSize,0); ctx.lineTo(0,triangleSize); ctx.fill();
    ctx.fillStyle = GAME_COLORS.RED; ctx.beginPath(); ctx.moveTo(WINDOW_WIDTH,0); ctx.lineTo(WINDOW_WIDTH-triangleSize,0); ctx.lineTo(WINDOW_WIDTH,triangleSize); ctx.fill();

    // Collectibles
    collectiblesRef.current.forEach(item => {
      ctx.fillStyle = item.type === 'G' ? GAME_COLORS.YELLOW : GAME_COLORS.PURPLE;
      ctx.beginPath(); ctx.arc(item.x, item.y, item.radius, 0, Math.PI*2); ctx.fill();
    });

    // Bases
    ctx.strokeStyle = '#333'; ctx.lineWidth = 2; ctx.strokeRect(redBase.x, redBase.y, 100, 100); ctx.strokeRect(blueBase.x, blueBase.y, 100, 100);

    // Robot
    ctx.fillStyle = '#fff'; ctx.fillRect(collectorRef.current.x, collectorRef.current.y, 50, 50);
    ctx.fillStyle = team === 'RED' ? GAME_COLORS.RED : GAME_COLORS.BLUE;
    ctx.beginPath(); ctx.arc(collectorRef.current.x+25, collectorRef.current.y+25, 10, 0, Math.PI*2); ctx.fill();
  };

  useEffect(() => {
    const down = (e: KeyboardEvent) => keysPressed.current.add(e.key.toLowerCase());
    const up = (e: KeyboardEvent) => keysPressed.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', down); window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  useEffect(() => {
    if (gameState === 'PLAYING') requestRef.current = requestAnimationFrame(update);
    else cancelAnimationFrame(requestRef.current);
    return () => cancelAnimationFrame(requestRef.current);
  }, [gameState, team, inventory]);

  return (
    <div className="relative w-full h-full bg-black overflow-hidden flex flex-col items-center justify-center">
      <canvas ref={canvasRef} width={WINDOW_WIDTH} height={WINDOW_HEIGHT} className="max-w-full h-auto border border-white/10" />
      
      {gameState === 'PLAYING' && (
        <div className="absolute top-4 left-4 text-yellow-500 font-black text-xl pointer-events-none">
          SCORE: {score} | TIME: {remainingTime}s | INV: {inventory.join('')}
        </div>
      )}

      <AnimatePresence>
        {gameState === 'FTC_SCREEN' && (
          <motion.div initial={{opacity:0}} animate={{opacity:1}} className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center cursor-pointer" onClick={() => setGameState('ALLIANCE_SELECT')}>
            <h2 className="text-6xl font-black italic text-white mb-4">DECODE SIM</h2>
            <p className="text-yellow-500 font-bold uppercase tracking-widest animate-pulse">Click to Initialize</p>
          </motion.div>
        )}
        {gameState === 'ALLIANCE_SELECT' && (
          <motion.div className="absolute inset-0 bg-black flex flex-col items-center justify-center gap-8">
            <h2 className="text-4xl font-black text-white italic">SELECT TEAM</h2>
            <div className="flex gap-8">
              <button onClick={() => { setTeam('RED'); setGameState('PLAYING'); setupCollectibles(); }} className="px-12 py-6 bg-red-600 font-black text-2xl rounded-2xl hover:scale-110 transition-transform">RED</button>
              <button onClick={() => { setTeam('BLUE'); setGameState('PLAYING'); setupCollectibles(); }} className="px-12 py-6 bg-blue-600 font-black text-2xl rounded-2xl hover:scale-110 transition-transform">BLUE</button>
            </div>
          </motion.div>
        )}
        {gameState === 'GAME_OVER' && (
          <motion.div className="absolute inset-0 bg-black flex flex-col items-center justify-center text-center">
            <h2 className="text-7xl font-black italic text-yellow-500 mb-4 uppercase">Mission Over</h2>
            <div className="text-3xl font-bold text-white mb-8">Final Score: {score}</div>
            <button onClick={() => window.location.reload()} className="px-10 py-4 bg-white text-black font-black uppercase rounded-xl">Restart</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FtcScorer: React.FC = () => {
  const [red, setRed] = useState({ art: 0, ov: 0, pat: 0, fouls: 0 });
  const [blue, setBlue] = useState({ art: 0, ov: 0, pat: 0, fouls: 0 });

  const update = (all: 'red' | 'blue', key: string, d: number) => {
    const s = all === 'red' ? setRed : setBlue;
    s((p: any) => ({ ...p, [key]: Math.max(0, p[key] + d) }));
  };

  const score = (d: any) => d.art * 3 + d.ov * 1 + d.pat * 2 + d.fouls;

  const Card = ({ title, data, all, color }: any) => (
    <div className={`p-8 rounded-3xl border-2 bg-zinc-900/50 backdrop-blur-xl border-${color}-500/30`}>
      <h3 className={`text-3xl font-black italic uppercase mb-6 text-${color}-500`}>{title} Alliance</h3>
      <div className="space-y-4">
        {['art', 'ov', 'pat'].map(k => (
          <div key={k} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
            <span className="font-bold uppercase text-xs tracking-widest">{k === 'art' ? 'Artifacts' : k === 'ov' ? 'Overflow' : 'Patterns'}</span>
            <div className="flex items-center gap-4">
              <button onClick={() => update(all, k, -1)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center"><Minus size={16}/></button>
              <span className="text-xl font-black w-6 text-center">{data[k]}</span>
              <button onClick={() => update(all, k, 1)} className="w-8 h-8 rounded-lg bg-yellow-500 text-black flex items-center justify-center"><Plus size={16}/></button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-8 pt-6 border-t border-white/10 flex justify-between items-end">
        <div><span className="text-[10px] uppercase font-bold text-gray-500">Score</span><div className={`text-5xl font-black text-${color}-500 italic`}>{score(data)}</div></div>
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <Card title="Red" data={red} all="red" color="red" />
      <Card title="Blue" data={blue} all="blue" color="blue" />
    </div>
  );
};

// --- MAIN APP ---

const App: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [gameVisible, setGameVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.offsetTop - 80, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-yellow-500 selection:text-black">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(234,179,8,0.05)_0%,transparent_70%)]" />
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px]" />
      </div>

      {/* Nav */}
      <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${scrolled ? 'bg-black/90 backdrop-blur-xl border-b border-yellow-500/20 py-3 shadow-2xl' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <img src={TEAM_LOGO} alt="Logo" className="w-12 h-12 group-hover:rotate-12 transition-transform" />
            <div className="flex flex-col"><span className="font-black text-xl italic leading-none">G-FORCE</span><span className="text-[10px] text-yellow-500 font-bold tracking-widest">19013</span></div>
          </div>
          <div className="hidden lg:flex items-center gap-8 text-[11px] font-black uppercase tracking-widest text-gray-400">
            {['hero', 'about', 'outreach', 'simulation', 'scorer', 'contact'].map(item => (
              <button key={item} onClick={() => scrollToSection(item === 'simulation' ? 'game' : item)} className="hover:text-yellow-400 transition-colors uppercase">{item}</button>
            ))}
          </div>
          <button className="lg:hidden p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>{mobileMenuOpen ? <X size={28}/> : <Menu size={28}/>}</button>
        </div>
      </nav>

      {/* Hero */}
      <section id="hero" className="min-h-screen flex items-center justify-center relative pt-20">
        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}>
            <img src={TEAM_LOGO} alt="Team G-Force Logo" className="w-48 h-48 mx-auto mb-8 drop-shadow-[0_0_30px_rgba(234,179,8,0.3)] animate-pulse-slow" />
            <h1 className="text-6xl md:text-9xl font-black italic tracking-tighter mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500 leading-tight">G-FORCE <span className="text-yellow-500">19013</span></h1>
            <p className="max-w-2xl mx-auto text-xl text-gray-400 mb-12">Engineering excellence in Mumbai. Join us on the journey through FTC DECODE.</p>
            <div className="flex gap-6 justify-center">
              <button onClick={() => scrollToSection('game')} className="px-10 py-5 bg-yellow-500 text-black font-black italic rounded-xl hover:scale-105 transition-all">INITIALIZE SIM</button>
              <button onClick={() => scrollToSection('scorer')} className="px-10 py-5 bg-white/5 border border-white/10 font-black italic rounded-xl hover:bg-white/10 transition-all">FTC SCORER</button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-32 border-y border-white/5">
        <div className="container mx-auto px-6 text-center max-w-4xl">
          <h2 className="text-5xl md:text-6xl font-black italic uppercase mb-8">Engineering <span className="text-yellow-500">Legacy</span></h2>
          <p className="text-xl md:text-2xl text-gray-300 leading-relaxed">G-Force (Team #19013) is a successful robotics team from Mumbai, India. Winning awards like Inspire and Promote, we have showcased talent in STEM since our rookie year in 2020.</p>
          <div className="flex justify-center gap-16 mt-12">
            <div className="flex flex-col"><span className="text-5xl font-black text-yellow-500 italic">2020</span><span className="text-xs uppercase tracking-widest text-gray-500">Rookie Year</span></div>
            <div className="w-px h-16 bg-white/10" />
            <div className="flex flex-col"><span className="text-5xl font-black text-yellow-500 italic">MUMBAI</span><span className="text-xs uppercase tracking-widest text-gray-500">Base</span></div>
          </div>
        </div>
      </section>

      {/* Outreach */}
      <section id="outreach" className="py-32 bg-zinc-950/50">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="max-w-2xl text-center md:text-left">
            <h2 className="text-5xl font-black italic uppercase mb-6 text-yellow-500">Outreach Impact</h2>
            <p className="text-xl text-gray-400">Promoting STEM and advocating for FIRST ideals through mentorship, events, and community service.</p>
          </div>
          <div className="bg-yellow-500/10 border border-yellow-500/20 px-8 py-4 rounded-full text-yellow-500 font-black italic flex items-center gap-3">
            <Users size={20}/> IMPACT: GLOBAL
          </div>
        </div>
      </section>

      {/* Simulation */}
      <section id="game" className="py-32 border-y border-white/5 bg-black">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-6xl font-black italic uppercase mb-12">Mission: DECODE</h2>
          <div className="relative aspect-video max-w-5xl mx-auto rounded-[2rem] border-2 border-yellow-500/30 overflow-hidden shadow-2xl bg-zinc-900 group">
             {!gameVisible ? (
               <div className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer bg-black/80 backdrop-blur-sm z-10" onClick={() => setGameVisible(true)}>
                  <div className="w-24 h-24 rounded-full border-2 border-yellow-500 flex items-center justify-center text-yellow-500 animate-pulse"><Play size={32} className="ml-1"/></div>
                  <span className="mt-6 font-black uppercase tracking-[0.5em] text-yellow-500">Access Simulator</span>
               </div>
             ) : <FtcDecodeGame />}
          </div>
        </div>
      </section>

      {/* Scorer */}
      <section id="scorer" className="py-32 bg-zinc-950">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16"><h2 className="text-5xl md:text-7xl font-black italic uppercase mb-4">FTC Scorer</h2><p className="text-gray-500 uppercase font-bold tracking-widest">Official DECODE Registry</p></div>
          <FtcScorer />
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-32 border-t border-white/10">
        <div className="container mx-auto px-6">
          <div className="bg-zinc-900/50 rounded-[3rem] border border-white/10 p-12 md:p-24 relative overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-6xl md:text-8xl font-black italic uppercase leading-none mb-8">CONTACT <br/><span className="text-yellow-500 text-6xl">US</span></h2>
                <div className="space-y-6">
                  <a href="mailto:omotecgforce@gmail.com" className="flex items-center gap-6 group">
                    <div className="w-14 h-14 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center group-hover:bg-yellow-500 group-hover:text-black transition-all"><Mail size={28}/></div>
                    <div className="flex flex-col"><span className="text-xs uppercase text-yellow-500 font-black">Email Registry</span><span className="text-xl font-bold">omotecgforce@gmail.com</span></div>
                  </a>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <a href="https://www.instagram.com/gforce_19013/" target="_blank" className="bg-black/40 border border-white/5 p-10 rounded-[2rem] text-center group hover:border-yellow-500/50 transition-all">
                  <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:bg-yellow-500 group-hover:text-black transition-all"><Instagram size={32}/></div>
                  <h3 className="text-xl font-black uppercase mb-1">Instagram</h3>
                  <span className="text-xs text-gray-500 font-bold tracking-widest">@GFORCE_19013</span>
                </a>
                <a href="https://www.youtube.com/@ftcgforce19013" target="_blank" className="bg-black/40 border border-white/5 p-10 rounded-[2rem] text-center group hover:border-red-500/50 transition-all">
                  <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-all"><Youtube size={32}/></div>
                  <h3 className="text-xl font-black uppercase mb-1">YouTube</h3>
                  <span className="text-xs text-gray-500 font-bold tracking-widest">CHANNEL</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/5">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4"><img src={TEAM_LOGO} alt="Logo" className="w-10 h-10"/><span className="font-black italic text-xl">G-FORCE 19013</span></div>
          <p className="text-gray-500 uppercase text-xs font-bold tracking-widest">© 2024 G-FORCE Robotics. Mission: Decode.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
